package com.browsermalvx;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipboardManager;
import android.content.ClipData;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.DownloadListener;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.net.URLEncoder;

public class MainActivity extends Activity {

    private WebView webView;
    private EditText urlInput;
    private boolean isPaused = false;
    private int darkTheme = AlertDialog.THEME_HOLO_DARK;

    private final String[] catNames = {"PC (Desktop)", "Celular (Mobile)", "Outros (Consoles)"};
    private final String[] uaPC_N = {"Windows - Chrome", "macOS - Safari", "Linux - Firefox"};
    private final String[] uaPC_V = {
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15",
        "Mozilla/5.0 (X11; Linux x86_64; rv:120.0) Gecko/20100101 Firefox/120.0"
    };
    private final String[] uaMob_N = {"Android (Padrão)", "iPhone - Safari", "Android - Firefox"};
    private final String[] uaMob_V = { null, "Mozilla/5.0 (iPhone; CPU iPhone OS 17_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Mobile/15E148 Safari/604.1", "Mozilla/5.0 (Android 14; Mobile; rv:120.0) Gecko/120.0 Firefox/120.0" };
    private final String[] uaOut_N = {"Xbox Series X", "PlayStation 5", "Nintendo Switch"};
    private final String[] uaOut_V = {
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; Xbox; Xbox Series X) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edge/120.0.0.0",
        "Mozilla/5.0 (PlayStation 5 8.20) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15",
        "Mozilla/5.0 (Nintendo Switch; WifiWebAuthApplet) AppleWebKit/601.6 (KHTML, like Gecko) NF/6.0.1.15.4 NintendoBrowser/5.1.0.23519"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = (WebView) findViewById(R.id.myWebView);
        urlInput = (EditText) findViewById(R.id.urlInput);
        final Button btnPause = (Button) findViewById(R.id.btnPause);
        final WebSettings settings = webView.getSettings();

        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);

        btnPause.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!isPaused) {
                        webView.onPause();
                        webView.pauseTimers(); 
                        btnPause.setText("▶");
                        btnPause.setBackgroundColor(0xFFCC0000);
                    } else {
                        webView.onResume();
                        webView.resumeTimers();
                        btnPause.setText("||");
                        btnPause.setBackgroundColor(0xFF333333);
                    }
                    isPaused = !isPaused;
                }
            });

        findViewById(R.id.btnFontPlus).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) { settings.setTextZoom(settings.getTextZoom() + 10); }
            });

        findViewById(R.id.btnFontMinus).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) { if (settings.getTextZoom() > 20) settings.setTextZoom(settings.getTextZoom() - 10); }
            });

        findViewById(R.id.btnReload).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) { webView.reload(); }
            });

        findViewById(R.id.btnUA).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) { showCatDialog(); }
            });

        webView.setDownloadListener(new DownloadListener() {
                @Override
                public void onDownloadStart(String url, String ua, String cd, String mt, long cl) {
                    showDownDialog(url);
                }
            });

        webView.setWebViewClient(new WebViewClient() {
                @Override
                public void onPageFinished(WebView v, String url) {
                    if (!urlInput.hasFocus()) urlInput.setText(url);
                }
            });

        urlInput.setOnEditorActionListener(new TextView.OnEditorActionListener() {
                @Override
                public boolean onEditorAction(TextView v, int actionId, KeyEvent e) {
                    if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE) {
                        processNav();
                        return true;
                    }
                    return false;
                }
            });

        findViewById(R.id.btnGo).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) { processNav(); }
            });

        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) { if(webView.canGoBack()) webView.goBack(); }
            });

        findViewById(R.id.btnForward).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) { if(webView.canGoForward()) webView.goForward(); }
            });

        // Captura o link ao iniciar
        handleIntent(getIntent());
    }

    private void handleIntent(Intent intent) {
        String action = intent.getAction();
        Uri data = intent.getData();

        if (Intent.ACTION_VIEW.equals(action) && data != null) {
            String url = data.toString();
            webView.loadUrl(url);
            urlInput.setText(url);
        } else {
            webView.loadUrl("https://www.google.com");
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    private void showDownDialog(final String url) {
        new AlertDialog.Builder(this, darkTheme)
            .setTitle("Download Interceptado")
            .setMessage("Deseja copiar o link deste arquivo?\n\nLink: " + url)
            .setPositiveButton("Copiar Link", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int i) {
                    ClipboardManager cb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    cb.setPrimaryClip(ClipData.newPlainText("URL", url));
                    Toast.makeText(MainActivity.this, "Copiado!", Toast.LENGTH_SHORT).show();
                }
            })
            .setNegativeButton("Ignorar", null)
            .show();
    }

    private void showCatDialog() {
        new AlertDialog.Builder(this, darkTheme).setTitle("Categorias").setItems(catNames, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    if (w == 0) showUAMenu("PC", uaPC_N, uaPC_V);
                    else if (w == 1) showUAMenu("Mobile", uaMob_N, uaMob_V);
                    else if (w == 2) showUAMenu("Consoles", uaOut_N, uaOut_V);
                }
            }).show();
    }

    private void showUAMenu(String t, final String[] n, final String[] v) {
        new AlertDialog.Builder(this, darkTheme).setTitle(t).setItems(n, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    webView.getSettings().setUserAgentString(v[w]);
                    webView.reload();
                }
            }).show();
    }

    private void processNav() {
        String input = urlInput.getText().toString().trim();
        if (input.isEmpty()) return;
        String finalUrl = (input.contains(".") && !input.contains(" ")) ? 
            (input.startsWith("http") ? input : "https://" + input) : 
            "https://www.google.com/search?q=" + URLEncoder.encode(input);

        urlInput.clearFocus();
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(urlInput.getWindowToken(), 0);
        webView.loadUrl(finalUrl);
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else showExitDialog();
    }

    private void showExitDialog() {
        new AlertDialog.Builder(this, darkTheme).setTitle("Sair").setMessage("Deseja fechar o navegador?")
            .setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int i) { finish(); }
            })
            .setNegativeButton("Não", null).show();
    }
}

